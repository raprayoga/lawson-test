

<?php $__env->startSection('content'); ?>

<section class="content">

    <!-- daterange picker -->
    <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/daterangepicker.css')); ?>">
    <!-- Tempusdominus Bbootstrap 4 -->
    <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/tempusdominus-bootstrap-4.min.css')); ?>">

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Add Products</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="text-center">
                <?php if(count($errors)): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors); ?>

                </div>
                <?php endif; ?>
            </div>

            <div class="container">
                <form action="<?php echo e(url('product/products/')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div id="form">
                        <div class="form-group">
                            <label for="name">Nama*</label>
                            <input type="text" class="form-control" id="name" aria-describedby="nameHelp" placeholder="Enter Nama ..." name="name" required>
                            <?php if($errors->get('name')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($errorname); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label>Merchant*</label>
                            <select class="form-control select2 select2-info" data-dropdown-css-class="select2-info" name="merchant_id" style="width: 100%;">
                                <option selected disabled> Select Merchant </option>
                                <?php $__currentLoopData = $datas['merchants']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merchant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($merchant->id); ?>"><?php echo e($merchant->merchant_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->get('merchant_id')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('merchant_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errormerchant_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($errormerchant_id); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row justify-content-between mt-5">
                        <a href="<?php echo e(url('product/products')); ?>" type="submit" class="btn btn-danger">Cancel</a>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.card-body -->
        </div>
</section>

<!-- InputMask -->
<script src="<?php echo e(url('/adminlte/plugins/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(url('/adminlte/plugins/js/jquery.inputmask.bundle.min.js')); ?>"></script>
<!-- date-range-picker -->
<script src="<?php echo e(url('/adminlte/plugins/js/daterangepicker.js')); ?>"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo e(url('/adminlte/plugins/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>

<script>
    //Date picker
    $('#expired_date').datetimepicker({
        format: 'YYYY-MM-DD'
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/template/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Codingan\lawson-test\resources\views/product/products/products_create.blade.php ENDPATH**/ ?>