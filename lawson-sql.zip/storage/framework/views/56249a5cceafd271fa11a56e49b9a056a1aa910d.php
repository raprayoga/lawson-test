

<?php $__env->startSection('content'); ?>

<section class="content">

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Add City</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="text-center">
                <?php if(count($errors)): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors); ?>

                </div>
                <?php endif; ?>
            </div>

            <div class="container">
                <form action="<?php echo e(url('product/city')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div id="form">
                        <div class="form-group">
                            <label for="name">Nama*</label>
                            <input type="text" class="form-control" id="name" aria-describedby="nameHelp" placeholder="Enter Nama ..." name="name" value="<?php echo e(old('name')); ?>" required>
                            <?php if($errors->get('name')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($errorname); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="longitude">Longitude*</label>
                            <input type="text" class="form-control" id="longitude" aria-describedby="longitudeHelp" placeholder="Enter Longitude ..." name="longitude" value="<?php echo e(old('longitude')); ?>" required>
                            <?php if($errors->get('longitude')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('longitude'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorlongitude): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($errorlongitude); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="latitude">latitude*</label>
                            <input type="text" class="form-control" id="latitude" aria-describedby="latitudeHelp" placeholder="Enter Latitude ..." name="latitude" value="<?php echo e(old('latitude')); ?>" required>
                            <?php if($errors->get('latitude')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('latitude'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorlatitude): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($errorlatitude); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row justify-content-between mt-5">
                        <a href="<?php echo e(url('product/city')); ?>" type="submit" class="btn btn-danger">Cancel</a>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.card-body -->
        </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/template/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lawson-test\resources\views/product/city/city_create.blade.php ENDPATH**/ ?>