

<?php $__env->startSection('content'); ?>

<section class="content">
    <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                    <span class="info-box-icon bg-info elevation-1"><i class="fas fa-users"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Apply Career</span>
                        <span class="info-box-number">
                            10
                        </span>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box mb-3">
                    <span class="info-box-icon bg-success elevation-1"><i class="fas fa-envelope"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Career Open Position</span>
                        15
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo e(url('/adminlte/plugins/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(url('/adminlte/plugins/js/Chart.min.js')); ?>"></script>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('/template/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Codingan\lawson-test\resources\views/beranda.blade.php ENDPATH**/ ?>