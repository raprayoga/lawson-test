

<?php $__env->startSection('content'); ?>

<section class="content">

    <!-- daterange picker -->
    <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/daterangepicker.css')); ?>">
    <!-- Tempusdominus Bbootstrap 4 -->
    <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/tempusdominus-bootstrap-4.min.css')); ?>">

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Add Order</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="text-center">
                <?php if(count($errors)): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors); ?>

                </div>
                <?php endif; ?>
            </div>

            <div class="container">
                <form action="<?php echo e(url('orders/order-item')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div id="form">
                        <div class="form-group">
                            <label for="quantity">Quantity*</label>
                            <input type="number" class="form-control" id="quantity" aria-describedby="quantityHelp" placeholder="Enter Quantity ..." name="quantity" value="<?php echo e(old('quantity')); ?>" required>
                            <?php if($errors->get('quantity')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('quantity'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorquantity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($errorquantity); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label>Product*</label>
                            <select class="form-control select2 select2-info" data-dropdown-css-class="select2-info" name="product_id" style="width: 100%;">
                                <option selected disabled> Select Product </option>
                                <?php $__currentLoopData = $datas['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->product_id); ?>"><?php echo e($product->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->get('product_id')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('product_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorproduct_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($errorproduct_id); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label>User*</label>
                            <select class="form-control select2 select2-info" data-dropdown-css-class="select2-info" name="user_id" style="width: 100%;">
                                <option selected disabled> Select User </option>
                                <?php $__currentLoopData = $datas['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->full_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->get('user_id')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('user_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erroruser_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($erroruser_id); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label>Status*</label>
                            <select class="form-control select2 select2-info" data-dropdown-css-class="select2-info" name="status_id" style="width: 100%;">
                                <option selected disabled> Select Status </option>
                                <?php $__currentLoopData = $datas['statuses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status->id); ?>"><?php echo e($status->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->get('status_id')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('status_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorstatus_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($errorstatus_id); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label>Date*</label>
                            <div class="input-group date" id="date" data-target-input="nearest">
                                <input type="text" class="form-control datetimepicker-input" placeholder="Enter Date" data-target="#date" name="date" value="<?php echo e(old('date')); ?>" required />
                                <div class="input-group-append" data-target="#date" data-toggle="datetimepicker">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                            <?php if($errors->get('date')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('date'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errordate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($errordate); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row justify-content-between mt-5">
                        <a href="<?php echo e(url('orders/order-item')); ?>" type="submit" class="btn btn-danger">Cancel</a>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.card-body -->
        </div>
</section>

<!-- InputMask -->
<script src="<?php echo e(url('/adminlte/plugins/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(url('/adminlte/plugins/js/jquery.inputmask.bundle.min.js')); ?>"></script>
<!-- date-range-picker -->
<script src="<?php echo e(url('/adminlte/plugins/js/daterangepicker.js')); ?>"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo e(url('/adminlte/plugins/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>

<script>
    //Date picker
    $('#date').datetimepicker({
        format: 'YYYY/MM/DD'
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/template/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lawson-test\resources\views/orders/order_item/order_item_create.blade.php ENDPATH**/ ?>