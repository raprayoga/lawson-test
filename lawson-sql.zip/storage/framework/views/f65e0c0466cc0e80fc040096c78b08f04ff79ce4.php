

<?php $__env->startSection('content'); ?>

<section class="content">

    <!-- daterange picker -->
    <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/daterangepicker.css')); ?>">
    <!-- Tempusdominus Bbootstrap 4 -->
    <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/tempusdominus-bootstrap-4.min.css')); ?>">

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Add Users</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="text-center">
                <?php if(count($errors)): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors); ?>

                </div>
                <?php endif; ?>
            </div>

            <div class="container">
                <form action="<?php echo e(url('users')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div id="form">
                        <div class="form-group">
                            <label for="full_name">Full Nama*</label>
                            <input type="text" class="form-control" id="full_name" aria-describedby="full_nameHelp" placeholder="Enter Nama ..." name="full_name" value="<?php echo e(old('full_name')); ?>" required>
                            <?php if($errors->get('full_name')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('full_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorfull_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($errorfull_name); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="phone">Phone*</label>
                            <input type="number" class="form-control" id="phone" aria-describedby="phoneHelp" placeholder="Enter Phone" name="phone" value="<?php echo e(old('phone')); ?>" required>
                            <?php if($errors->get('phone')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('phone'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorphone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($errorphone); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="email">Email*</label>
                            <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter Email" name="email" value="<?php echo e(old('email')); ?>" required>
                            <?php if($errors->get('email')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erroremail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($erroremail); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="address">Address*</label>
                            <textarea class="textarea" name="address" placeholder="Enter Address" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo e(old('address')); ?></textarea>
                            <?php if($errors->get('address')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('address'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erroraddress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($erroraddress); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label>Tgl Lahir*</label>
                            <div class="input-group date" id="date_of_birth" data-target-input="nearest">
                                <input type="text" class="form-control datetimepicker-input" placeholder="Enter Tgl Lahir" data-target="#date_of_birth" name="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>" required />
                                <div class="input-group-append" data-target="#date_of_birth" data-toggle="datetimepicker">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                            <?php if($errors->get('date_of_birth')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('date_of_birth'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errordate_of_birth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($errordate_of_birth); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="active">Active*</label>
                            <select class="custom-select" id="active" name="active" required>
                                <option selected>Choose...</option>
                                <option value="y" <?php if (old('active')  == 'y') echo 'selected' ?>>Yes</option>
                                <option value="n" <?php if (old('active')  == 'n') echo 'selected' ?>>No</option>
                            </select>
                            <?php if($errors->get('active')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('active'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erroractive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($erroractive); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row justify-content-between mt-5">
                        <a href="<?php echo e(url('users')); ?>" type="submit" class="btn btn-danger">Cancel</a>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.card-body -->
        </div>
</section>

<!-- InputMask -->
<script src="<?php echo e(url('/adminlte/plugins/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(url('/adminlte/plugins/js/jquery.inputmask.bundle.min.js')); ?>"></script>
<!-- date-range-picker -->
<script src="<?php echo e(url('/adminlte/plugins/js/daterangepicker.js')); ?>"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo e(url('/adminlte/plugins/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>

<script>
    //Date picker
    $('#date_of_birth').datetimepicker({
        format: 'YYYY-MM-DD'
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/template/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Codingan\lawson-test\resources\views/users/users_create.blade.php ENDPATH**/ ?>