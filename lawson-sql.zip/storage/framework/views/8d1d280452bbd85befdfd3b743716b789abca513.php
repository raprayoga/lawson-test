

<?php $__env->startSection('content'); ?>

<section class="content">

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Edit Master Status</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="text-center">
                <?php if(count($errors)): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors); ?>

                </div>
                <?php endif; ?>
            </div>

            <div class="container">
                <form action="<?php echo e(url('orders/master-status/'.$data->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div id="form">
                        <div class="form-group">
                            <label for="name">Nama*</label>
                            <input type="text" class="form-control" id="name" aria-describedby="nameHelp" placeholder="Enter Nama ..." name="name" value="<?php echo e($data->name); ?>" required>
                            <?php if($errors->get('name')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($errorname); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="description">Description*</label>
                            <textarea class="textarea" name="description" placeholder="Enter description" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo e($data->description); ?></textarea>
                            <?php if($errors->get('description')): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <ul style="list-style: none;">
                                    <?php $__currentLoopData = $errors->get('description'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errordescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($errordescription); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row justify-content-between mt-5">
                        <a href="<?php echo e(url('orders/master-status')); ?>" type="submit" class="btn btn-danger">Cancel</a>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.card-body -->
        </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/template/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Codingan\lawson-test\resources\views/orders/master_status/master_status_edit.blade.php ENDPATH**/ ?>